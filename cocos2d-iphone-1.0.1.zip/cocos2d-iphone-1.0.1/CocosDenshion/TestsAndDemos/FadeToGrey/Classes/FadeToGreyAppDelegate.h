//
//  FadeToGreyAppDelegate.h
//  FadeToGrey
//
//  Created by Stephen Oldmeadow on 5/03/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FadeToGreyAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
