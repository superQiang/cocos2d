//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocos2DSubclass___ {
    
}

@end
