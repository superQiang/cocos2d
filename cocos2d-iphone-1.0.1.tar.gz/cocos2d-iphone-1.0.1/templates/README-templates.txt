Xcode 4 templates:
------------------


The Xcode4 template format is not documented, so the the current templates doesn't have all
the power of the Xcode3 templates. Once the format is documented, more functionality will be added.


Xcode4 templates are based on this document:
http://blog.boreal-kiss.net/2011/03/11/a-minimal-project-template-for-xcode-4/

