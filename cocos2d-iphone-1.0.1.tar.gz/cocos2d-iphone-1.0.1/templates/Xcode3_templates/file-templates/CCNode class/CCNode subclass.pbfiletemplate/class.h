//
//  «FILENAME»
//  «PROJECTNAME»
//
//  Created by «FULLUSERNAME» on «DATE».
//  Copyright «YEAR» «ORGANIZATIONNAME». All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface «FILEBASENAMEASIDENTIFIER» : CCNode {

}

@end
