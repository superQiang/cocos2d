#import "cocos2d.h"

//CLASS INTERFACE
@interface AppController : NSObject
{
	UIWindow	*window;
}
@end

@interface FontTest : CCLayer
{
}
@end



