Tiler.mm by Ernesto Corvi

Tiler is a small command line utility that tiles an arbitrary image
into a PNG texture containing tiles and a TGA image containing a tilemap.
You can specify the tile size (must be a power of 2) with the -tilesize option.
